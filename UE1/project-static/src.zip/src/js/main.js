import * as MainNav from './lib/mainnav.js';
window.MainNav = MainNav;
